package com.bt.employee.serviceimpl;

import java.io.IOException;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bt.employee.entity.EmployeeEntity;
import com.bt.employee.entity.UserEntity;
import com.bt.employee.exception.EmployeeApplicationException;
import com.bt.employee.model.Employee;
import com.bt.employee.model.User;
import com.bt.employee.repo.UserRepository;
import com.bt.employee.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private UserRepository userRepo;

	@Override
	@Transactional
	public Employee getEmployeeDetails(long userId) throws IOException, EmployeeApplicationException {
		Employee employee = new Employee();

		Optional<UserEntity> empDet = userRepo.findById(userId);
		if (empDet.isPresent()) {
			UserEntity emp = empDet.get();
			EmployeeEntity empEntity = emp.getEmployeeEntity();
			if (empEntity == null) {
				throw new EmployeeApplicationException("Mapping incorrect");
			}
			employee = constructEmployeeModel(empEntity);
			return employee;
		} else
			throw new EmployeeApplicationException("No data found");

	}

	@Override
	public User login(long userId, String password) throws IOException, EmployeeApplicationException {
		User user = new User();

		Optional<UserEntity> userEntity = userRepo.findById(userId);
		if (userEntity.isPresent()) {
			UserEntity userDetails = userEntity.get();
			user = constructUserModel(userDetails);
			if (user.getPwd().equals(password))
				return user;
			else
				throw new EmployeeApplicationException("Employee id or password is incorrect");
		} else {

			throw new EmployeeApplicationException("Not a registered user");
		}

	}

	private Employee constructEmployeeModel(EmployeeEntity empEntity) throws NullPointerException {
		Employee employee = new Employee();
		employee.setEmpId(empEntity.getEmpId());
		employee.setEmpName(empEntity.getEmpName());
		employee.setDesg(empEntity.getDesg());
		employee.setDoj(empEntity.getDoj());
		employee.setAddress(empEntity.getAddress());
		return employee;

	}

	private User constructUserModel(UserEntity userEntity) throws NullPointerException {
		User user = new User();
		user.setUserId(userEntity.getUserId());
		user.setPwd(userEntity.getPwd());

		return user;
	}

}
