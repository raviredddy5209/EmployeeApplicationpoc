package com.bt.employee.service;

import java.io.IOException;


import com.bt.employee.exception.EmployeeApplicationException;
import com.bt.employee.model.Employee;
import com.bt.employee.model.User;

public interface EmployeeService {

	Employee getEmployeeDetails(long empId) throws IOException, EmployeeApplicationException;

	User login(long empId, String password) throws IOException, EmployeeApplicationException;
}
