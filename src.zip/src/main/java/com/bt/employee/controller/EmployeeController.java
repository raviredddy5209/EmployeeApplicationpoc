package com.bt.employee.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bt.employee.exception.EmployeeApplicationException;
import com.bt.employee.model.Employee;
import com.bt.employee.model.User;
import com.bt.employee.service.EmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	private EmployeeService empService;

	@GetMapping("/employeedetails")
	public ResponseEntity<Employee> getEmployee(@RequestParam("userid") long userId)
			throws IOException, EmployeeApplicationException {
		Employee empDet = empService.getEmployeeDetails(userId);
		System.out.println("entering into employee .....");
		return new ResponseEntity<Employee>(empDet, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/employeelogin")
	public ResponseEntity<String> employeeLogin(@RequestParam("userid") long userId,
			@RequestParam("password") String password) throws IOException, EmployeeApplicationException {
		User user = empService.login(userId, password);

		if (user == null)

		{
			System.out.println("login unsuccessful");
			return new ResponseEntity<String>("login unsuccessful", new HttpHeaders(), HttpStatus.UNAUTHORIZED);
		} else {
			System.out.println("login successful");
			return new ResponseEntity<String>("login successful", new HttpHeaders(), HttpStatus.OK);

		}

	}

}
