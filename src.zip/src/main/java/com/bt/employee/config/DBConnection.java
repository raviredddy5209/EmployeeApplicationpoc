package com.bt.employee.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DBConnection {
	@Value("${spring.datasource.url}")
	private String connURL;

	@Value("${spring.datasource.username}")
	private String connUserName;

	@Value("${spring.datasource.password}")
	private String connPassword;

	private Connection con;

	public Connection connectToDb() {
		try {
			con = DriverManager.getConnection(connURL, connUserName, connPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return con;

	}
}
