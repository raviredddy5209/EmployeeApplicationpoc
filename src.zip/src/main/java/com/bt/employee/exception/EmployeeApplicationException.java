package com.bt.employee.exception;

public class EmployeeApplicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeApplicationException(String message) {
		super(message);
		System.out.println(message);

	}

	public EmployeeApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	public EmployeeApplicationException(Throwable cause) {
		super(cause);
	}

}
